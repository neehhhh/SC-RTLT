PUBLIC REAL TIME CHECKER 1.3.2 — WINDOWS 11

Outil communautaire non officiel pour Star Citizen.

FONCTIONNEMENT
- La lecture locale de Game.log reste active pour la localisation automatique.
- Game.log est ouvert en lecture seule et n'est jamais copié dans le registre.
- Le bouton Wi-Fi demande au joueur le nom réel du lieu.
- Lors de la validation, l'application associe ce texte au dernier code de localisation physique jugé le plus probable.
- Les destinations Starmap ont une priorité inférieure aux événements physiques récents.
- Aucun enregistrement passif, JSONL, CSV ou TSV n'est produit.

FICHIER À TRANSMETTRE
%LOCALAPPDATA%\PublicRealTimeCheckerData\registry\Public_Real_Time_Checker_Registry.json

C'est le seul fichier nécessaire au registre communautaire. Le joueur ne doit pas envoyer son Game.log.

INSTALLATION
1. Extraire entièrement le ZIP.
2. Ouvrir le dossier Public_Real_Time_Checker_1.3.2_Windows.
3. Double-cliquer sur Setup.bat.
4. Utiliser Launcher.vbs pour relancer l'application.
5. En cas d'échec, consulter le fichier Public_Real_Time_Checker-install.log copié sur le Bureau.

Le programme s'installe séparément de SC RTLT afin de ne pas remplacer une version privée. Il peut toutefois réutiliser le runtime graphique d'une installation SC RTLT existante.
