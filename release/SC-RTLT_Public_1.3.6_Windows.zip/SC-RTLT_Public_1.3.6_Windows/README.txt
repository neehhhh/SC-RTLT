SC-RTLT PUBLIC 1.3.6 — WINDOWS 11

Outil communautaire non officiel pour Star Citizen.

CORRECTIF 1.3.6
- Bug fix : Widget is no longer masking upon death
- Les demandes d’inventaire générées automatiquement pendant la réapparition du joueur ne masquent plus le widget.
- Le masquage normal lors d’une véritable ouverture de l’inventaire est conservé.

MISE À JOUR GITHUB
- Le bouton jaune VÉRIFIER LES MISES À JOUR se trouve en haut de la page Réglages.
- Il consulte uniquement la dernière Release publique du dépôt neehhhh/SC-RTLT.
- Lorsqu’une version plus récente existe, le package Windows est téléchargé puis vérifié.
- Si la Release contient SHA256SUMS.txt, son empreinte SHA-256 est contrôlée avant toute installation.
- L’installateur se lance automatiquement, ferme l’ancienne version puis rouvre directement le widget normal.
- Aucun token GitHub, mot de passe ou identifiant personnel n’est intégré au programme.

FONCTIONNEMENT
- La webapp et le widget normal sont les deux seules vues disponibles.
- Le switch de la webapp ou du widget permet de passer directement d’une vue à l’autre.
- Aucun délai ne bascule automatiquement la webapp vers le widget.
- Le widget reste visible dans les interfaces du jeu ; seul l’inventaire peut le masquer temporairement si l’option dédiée est activée.
- La lecture locale de Game.log reste active pour la localisation automatique.
- Game.log est ouvert en lecture seule et n'est jamais copié dans le registre.
- Le bouton Wi-Fi demande au joueur le nom réel du lieu.
- Lors de la validation, l'application associe ce texte au dernier code de localisation physique jugé le plus probable.
- Les destinations Starmap ont une priorité inférieure aux événements physiques récents.
- Aucun enregistrement passif, JSONL, CSV ou TSV n'est produit.

FICHIER À TRANSMETTRE
%LOCALAPPDATA%\SCRTLTPublicData\registry\SC-RTLT_Public_Registry.json

C'est le seul fichier nécessaire au registre communautaire. Le joueur ne doit pas envoyer son Game.log.

INSTALLATION
1. Extraire entièrement le ZIP.
2. Ouvrir le dossier SC-RTLT_Public_1.3.6_Windows.
3. Double-cliquer sur Setup.bat.
4. Utiliser Launcher.vbs pour relancer l'application.
5. En cas d'échec, consulter le fichier SC-RTLT_Public-install.log copié sur le Bureau.

Le programme s'installe séparément de SC-RTLT afin de ne pas remplacer une version privée. Il peut toutefois réutiliser le runtime graphique d'une installation SC-RTLT existante.

RADIO
- Les stations HCN et The People's Radio restent disponibles.
- Huit stations REC·REG sont ajoutées : Rock, Western, Punk, Lounge, Metal, Country, Groovy et Old Times.
- Chaque station REC·REG utilise son flux MP3 direct et ses métadonnées artiste/titre propres.
