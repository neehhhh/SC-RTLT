SC-RTLT PUBLIC 2.1.20 — WINDOWS 11

MISE À JOUR 2.1.20 — EXCEPTION HANGAR QUEUE

- Corrige le faux membre `Hangar` créé par la notification Star Citizen `Joined hangar queue`.
- La correction est volontairement limitée à cette notification cargo/ATC : un vrai joueur dont le handle est `Hangar` reste détectable dans une vraie notification Party.
- Aucun changement Cloudflare, relay, Party/RAID, HUD, vaisseau, localisation ou radio.
- Le validateur Windows contient désormais un test anti-régression permanent reproduisant exactement cette notification multiligne.

SC-RTLT PUBLIC 2.1.19 — WINDOWS 11

MISE À JOUR 2.1.19 — CORRECTION DU VALIDATEUR D’INSTALLATION

- Corrige l’échec du validateur 2.1.18 qui cherchait l’ancien nom `_paint_group_reduced`.
- Le contrôle HUD extrait désormais une méthode jusqu’à la méthode suivante, sans dépendre d’un nom obsolète.
- Aucun comportement de l’application n’est modifié par rapport au 2.1.18 : le leader reste suivi mais sans couleur spéciale.

SC-RTLT PUBLIC 2.1.18 — WINDOWS 11

MISE À JOUR 2.1.18 — LEADER SANS COULEUR SPÉCIALE

- Le leader de Party reste détecté et suivi normalement.
- Le leader n'utilise plus de trait doré ni de couleur HUD spéciale.
- En RAID, son trait reprend la couleur normale de son vaisseau, exactement comme les autres occupants du même vaisseau.
- En mode Group normal, son trait horizontal utilise la couleur normale du groupe.
- Aucun autre comportement Party/RAID, regroupement par vaisseau, identité, titre, organisation ou localisation n'est modifié.

SC-RTLT PUBLIC 2.1.17 — WINDOWS 11

MISE À JOUR 2.1.17 — CORRECTION VILLES / STATIONS
- Corrige Lorville qui pouvait rester affichée comme Everus Harbor.
- Corrige New Babbage qui pouvait rester affichée comme Port Tressler.
- La même correction couvre Area18/Baijini Point et Orison/Seraphim Station.
- Un token LocationManager générique de planète n’est plus promu automatiquement vers la station orbitale correspondante.
- Une détection précise de landing zone remplace immédiatement un ancien indice de station sur la même planète.
- Le validateur Windows contient désormais un test anti-régression permanent pour les quatre grandes villes et leurs stations orbitales.

SC-RTLT PUBLIC 2.1.16 — WINDOWS 11

MISE À JOUR 2.1.16 — VALIDATION RAID + LEADER
- Corrige le validateur 2.1.15 : il vérifie désormais que les occupants d’un même vaisseau sont adjacents sans imposer un ordre interne artificiel contraire à l’ancrage historique du HUD.
- Corrige la régression où les channels portant seulement le modèle `Perseus`, `Ironclad` ou `Ironclad Assault` étaient rejetés avant la logique RAID.
- Les joueurs qui partagent le même channel de vaisseau sont de nouveau regroupés côte à côte dans le RAID ; quatre occupants du même Perseus restent donc adjacents.
- Le trait RAID reprend automatiquement la palette du vaisseau reconnu ; à la sortie du channel, le joueur revient au trait HUD normal et le groupe se réorganise.
- Le leader de Party est suivi depuis la création locale, l’acceptation d’une invitation entrante et les transferts de leadership explicites.
- En RAID, le trait du leader est doré et reste prioritaire sur la couleur du vaisseau.
- En mode Group normal, le trait horizontal du leader est doré, y compris sur le bloc du joueur local lorsqu’il est chef de groupe.
- Le leader est conservé pendant la transition Frontend -> PU `Party Disbanded` / `You have created party` lorsqu’elle est identifiée comme transition.
- Le validateur Windows contient désormais un scénario comportemental permanent qui vérifie la reconnaissance Perseus/Ironclad, le regroupement réel des joueurs et la priorité visuelle du leader.

SC-RTLT PUBLIC 2.1.14 — WINDOWS 11

MISE À JOUR 2.1.14 — COMPATIBILITÉ GAME.LOG RELAYTEST
- Corrige la cause générale de la régression des anciens RelayTest, sans dépendre d’un nom de fichier ou d’une seule variante de log.
- Les PartyMarker historiques sans `marker id` et les PartyMarker actuels avec `marker id` sont tous deux reconnus comme preuves de cardinalité du groupe.
- Tout Game.log choisi manuellement hors des vrais chemins RSI `StarCitizen\LIVE`, `PTU`, `EPTU` ou `TECH-PREVIEW` est considéré comme rejouable, même s’il est renommé ou copié ailleurs.
- Le replay externe relit jusqu’à 128 MiB en streaming au lieu de 16 MiB, afin de retrouver le roster créé tôt dans un scénario.
- Un contrôle de continuité détecte aussi les troncatures/réécritures très rapides du même fichier lorsque taille et inode ne suffisent pas.
- Après replay, SC-RTLT reprend le suivi incrémental normal des nouvelles lignes du RelayTest.
- Le vrai Game.log de Star Citizen conserve son comportement prudent et n’est jamais soumis au replay complet.
- Aucun module RelayTest n’est distribué dans le build public ; seule la compatibilité avec des Game.log externes est restaurée.

SC-RTLT PUBLIC 2.1.12 — WINDOWS 11

MISE À JOUR 2.1.12 — MEMBRES NON-RTLT RECONSTRUITS DEPUIS GAME.LOG
- Les joueurs sans SC-RTLT ne dépendent plus de Cloudflare pour apparaître dans le Group/RAID : les preuves Party du Game.log local créent directement leur membre.
- La notification HUD multiligne réelle `Party / <handle> connected.` est reconnue comme preuve nommée et déclenche immédiatement la ligne joueur + la recherche du profil RSI.
- `MissionShared ... ownerId[GEID]` est maintenant une preuve Party GEID directe. Quand le HUD `Contract Shared` ne contient aucun nom, SC-RTLT crée une identité GEID en attente au lieu d'ignorer le joueur.
- Les `CPartyMarkerComponent` mémorisent maintenant `PartyMemberMarker_<id> -> TrackedEntityId/GEID`; les événements QT visant ce marker renforcent l'appartenance du GEID au groupe.
- Les QT nommés acceptent aussi la forme `Initiated by party leader <handle>`, tout en excluant toujours `Party Launching / Join Party In PU`.
- Le faux couple SC 4.9 `Party Disbanded` puis `You have created party` à quelques millisecondes lors du passage Frontend -> PU est identifié comme transition : les preuves nom/GEID du même Game.log sont restaurées au lieu d'être perdues.
- Un vrai `You have left the party` reste définitif et vide ces preuves ; une création de Party ultérieure hors transition repart proprement.
- Au redémarrage du widget, la reconstruction Party relit jusqu'à 128 MiB du Game.log courant avec un parseur Party léger, tandis que la récupération de localisation reste limitée à 2 MiB.
- Les corrections 2.1.8 (identité invitant et Group depuis le bas) restent présentes.

SC-RTLT PUBLIC 2.1.10 — WINDOWS 11

MISE À JOUR 2.1.10 — NOTIFICATIONS NOMMÉES = PREUVE PARTY
- Corrige la logique introduite par erreur en 2.1.9 : pour les notifications Party-only que Star Citizen affiche avec un handle, le nom est lui-même une preuve directe que ce joueur appartient au groupe actif.
- `Player Connected <handle>` peut maintenant créer/résoudre immédiatement le membre, même si SC-RTLT ne connaissait pas encore son GEID.
- `<handle> is sharing a mission` et les variantes de mission partagée nommées créent/résolvent également ce membre dans le Group/RAID.
- Les notifications QT de groupe nommées (par exemple `... Initiated by <handle>` ou `<handle> initiated QT jump for the group`) ont la même valeur de preuve Party.
- Une notification QT générique sans handle ne crée aucun joueur. `Party Launching / Join Party In PU` et les groupes/channels Social personnalisés restent explicitement exclus.
- Une preuve nommée récente peut rouvrir une génération Party qu'un teardown Frontend obsolète venait de fermer.
- Le profil RSI du joueur nouvellement confirmé est demandé immédiatement ; le GEID peut être rattaché plus tard par les preuves PartyMarker sans perdre le handle.
- Les corrections 2.1.8 (identité conservée pendant le passage Frontend → PU et Group ancré en bas) restent présentes.
- Aucun changement du protocole Cloudflare v3 ni du Relay 1.1.1.

SC-RTLT PUBLIC 2.1.8 — WINDOWS 11

MISE À JOUR 2.1.8 — IDENTITÉ PARTY + GROUPE DEPUIS LE BAS
- Corrige la perte d’identité d’un invitant lors du passage Frontend → PU : après l’acceptation d’une invitation entrante nommée, le GEID demandé par le service Social est corrélé uniquement à cet invitant unique.
- La correspondance GEID ↔ handle reste strictement en mémoire pour le Game.log courant et n’est pas persistée dans le build ni entre deux sessions Game.log.
- Un `Party Disbanded` de transition peut toujours vider le roster, mais il n’efface plus une identité déjà prouvée dans la session ; le PartyMarker suivant peut donc restaurer directement le bon profil au lieu de rester sur WAITING FOR IDENTITY.
- Le Group normal est de nouveau ancré en bas : le premier membre distant apparaît dans le slot inférieur, puis les suivants s’empilent vers le haut.
- Le mode RAID conserve son ancrage en haut et son regroupement par vaisseau.
- Le visualisateur HUD Custom utilise de nouveau l’empreinte complète de 150 px pour le Group normal afin de ne pas couper le slot inférieur.
- Le validateur Windows couvre désormais la corrélation d’identité de l’invitant, la conservation de l’identité pendant un teardown Party et la géométrie Group depuis le bas.
- Aucun changement du protocole Cloudflare v3 ni du Relay 1.1.1.

SC-RTLT PUBLIC 2.1.7 — WINDOWS 11

MISE À JOUR 2.1.7 — VALIDATEUR ORDRE RAID
- Corrige le validateur Windows qui exigeait encore la phrase-commentaire `marker + title icon + handle`, absente du rendu RAID actuel.
- Le contrôle vérifie maintenant directement dans `_paint_group_raid` que le trait est dessiné avant l’icône de titre, puis que le handle est dessiné après cette icône.
- La position du placeholder des identités inconnues reste contrôlée séparément.
- Aucun changement fonctionnel du RAID 2.1.5/2.1.6 : regroupement par channel de vaisseau, gradients et transition de 220 ms inchangés.
- Toutes les corrections précédentes restent présentes.

SC-RTLT PUBLIC 2.1.6 — WINDOWS 11

MISE À JOUR 2.1.6 — CORRECTION VALIDATEUR RAID
- Corrige le validateur Windows qui cherchait encore l’ancienne expression de géométrie RAID `y = row * row_height`, supprimée par l’animation de regroupement 2.1.5.
- Le validateur contrôle maintenant la géométrie réellement utilisée par `_raid_animated_positions` : colonne, index de ligne, ancrage du premier slot à y=0 et pas vertical `_RAID_HUD_ROW_HEIGHT`.
- Aucun changement fonctionnel du regroupement RAID 2.1.5 : mêmes channels de vaisseau, mêmes gradients et même transition de 220 ms.
- Toutes les corrections précédentes restent présentes.

SC-RTLT PUBLIC 2.1.5 — WINDOWS 11

MISE À JOUR 2.1.5 — RAID : GROUPES DE VAISSEAUX
- En mode RAID, les membres qui partagent le même channel de vaisseau sont regroupés côte à côte dans l’ordre du roster, sans tri alphabétique global.
- Le trait RAID d’un membre en vaisseau utilise un dégradé dérivé de la palette HUD du constructeur, nuancé de façon déterministe par le channel afin que les occupants du même vaisseau aient exactement le même repère visuel.
- Le réordonnancement des nameplates est animé sur 220 ms avec une interpolation smoothstep rapide et fluide.
- À la sortie d’un channel de vaisseau, le membre revient au trait RAID bleu normal et le roster se réorganise automatiquement avec la même transition.
- Le joueur local reste exclu de la grille RAID.
- Aucun changement du protocole Cloudflare v3 ni du Relay 1.1.1.

HISTORIQUE DES VERSIONS PRÉCÉDENTES

SC-RTLT PUBLIC 2.1.4 — WINDOWS 11

MISE À JOUR 2.1.4 — HUD EDITOR GROUP / RAID
- Le cadre party_group du visualisateur HUD Custom utilise maintenant la hauteur réellement visible du preview Group.
- Le preview standard contient trois membres distants : 3 × 37,5 px = 112,5 px, arrondis à 113 px pour le masque et le cadre de placement, au lieu de conserver l'ancien cadre de 150 px.
- Le cadre du HUD Editor et le rendu Party affiché pendant l'édition utilisent donc le même ancrage haut et la même empreinte visible.
- Le passage Group / RAID ne donne plus l'impression que le bloc Group descend plus bas uniquement dans le visualisateur des Réglages.
- Toutes les corrections 2.1.3 et 2.1.2 restent présentes.
- Aucun changement du protocole Cloudflare v3 ni du Relay 1.1.1.

SC-RTLT PUBLIC 2.1.3 — WINDOWS 11

MISE À JOUR 2.1.3 — ALIGNEMENT GROUP / RAID
- Le bloc Group normal et le mode RAID partagent maintenant exactement le même ancrage haut du bloc party_group.
- Les slots du Group normal restent fixes à 37,5 px, mais le premier membre commence à y=0 au lieu d'être décalé vers le bas selon le nombre de membres.
- Le passage de trois membres distants au quatrième (activation du RAID) ne fait donc plus sauter verticalement le roster.
- La position x/y choisie dans le HUD Editor reste la référence unique pour les deux modes.
- Les corrections 2.1.2 restent présentes : changement immédiat du Game.log au Save, confirmation jaune APPLIQUÉ/APPLIED et icône de titre devant le nom en RAID.
- Aucun changement du protocole Cloudflare v3 ni du Relay 1.1.1.

SC-RTLT PUBLIC 2.1.2 — WINDOWS 11

MISE À JOUR 2.1.2 — APPLICATION IMMÉDIATE + RAID
- Le bouton Enregistrer les réglages / Save settings devient jaune et affiche APPLIQUÉ / APPLIED pendant 1,8 seconde après l’enregistrement.
- Un Game.log choisi manuellement devient maintenant prioritaire immédiatement après Enregistrer les réglages, même si l’ancien Game.log a une date de modification plus récente. Il n’est plus nécessaire de relancer le widget pour changer de fichier.
- En mode RAID, l’icône du titre RSI est maintenant placée devant le nom du joueur au lieu d’être affichée après le nom.
- Aucun changement du protocole v3 ni du relais Cloudflare : Relay 1.1.1 reste compatible et ne nécessite aucun redéploiement.

MISE À JOUR 2.1.1 — CLARIFICATION ADRESSE IP
- Le consentement FR/EN précise maintenant que SC-RTLT n’inclut pas l’adresse IP dans les données de jeu partagées.
- Comme pour toute connexion Internet, Cloudflare peut néanmoins traiter l’adresse IP au niveau réseau comme métadonnée technique nécessaire au relais.
- PRIVACY.txt reprend la même distinction entre données applicatives SC-RTLT et métadonnées réseau.
- Aucun changement du protocole v3, du chiffrement ou du relais Cloudflare 1.1.0 : aucun nouveau déploiement Cloudflare n’est nécessaire pour cette version.

MISE À JOUR 2.1.0 — CONSENTEMENT + RELAIS PRIVACY
- Le partage temps réel est OFF par défaut, y compris lors de la migration depuis une version antérieure qui pouvait être ON.
- Réglages > Partage temps réel — Alpha utilise maintenant un bouton ON/OFF explicite.
- Chaque passage de OFF vers ON affiche un consentement complet dans la langue active de l’application (FR ou EN). ANNULER laisse le partage sur OFF.
- Le consentement accepté et son retrait éventuel sont horodatés uniquement dans les réglages locaux.
- Le protocole temps réel passe en v3 : le HELLO en clair ne contient plus le handle RSI, le GEID ni le mode de rendez-vous. Ces identités passent uniquement après établissement X25519 dans un événement AES-256-GCM signé.
- Les rooms GEID refusent tout événement ordinaire tant que le couple handle/GEID chiffré du pair n’a pas été validé.
- PRIVACY.txt est réécrit en FR/EN avec finalités, catégories de données, destinataires, conservation, retrait et droits.
- Le paquet Cloudflare associé désactive les invocation logs et route les Durable Objects de room vers la juridiction UE.
- Le partage v3 nécessite que les membres concernés utilisent une version compatible 2.1.0 ; les anciens clients v2 restent isolés dans leurs anciennes rooms.
- Relais associé : SC-RTLT Cloudflare 1.1.0.
- Le Game.log brut reste strictement local ; `INCOMING CALL` reste strictement local.

NOTE DE VERSION
La base fournie était 2.0.0. Le numéro 2.1.0 conserve l’ordre de mise à jour ; utiliser 1.2.0 aurait créé un downgrade et aurait pu être considéré comme ancien par l’updater.

MISE À JOUR 2.0.0 — LOCALISATION PARTY TEMPS RÉEL
- La localisation du joueur principal reste uniquement dans le HUD principal et ne remplace plus son titre RSI dans son bloc joueur.
- Chaque changement de lieu confirmé est partagé sous forme d’un événement sémantique `player_location`, chiffré/signé, uniquement avec les membres déjà prouvés par la Party locale.
- Sur les blocs des autres membres qui utilisent SC-RTLT, la dernière localisation reçue reste affichée à la place du titre RSI.
- Priorité d’affichage distante : channel vaisseau > notification temporaire définie > localisation persistante > titre RSI.
- À la sortie du vaisseau, le joueur principal revient directement à son titre ; chez les autres membres, sa localisation reçue devient l’état visible.
- Le partage temps réel reste désactivable depuis les Réglages et `INCOMING CALL` reste strictement local.


MISE À JOUR 1.5.42 — INTERRUPTEUR PARTAGE TEMPS RÉEL
- Réglages > Partage temps réel — Alpha contient maintenant `Activer le partage temps réel`.
- Activé par défaut ; le choix est mémorisé.
- Désactivé : toutes les connexions Cloudflare sont fermées et aucun événement temps réel n’est envoyé ni reçu. Le traitement local du Game.log et le widget restent actifs.
- Réactivé : reconnexion automatique uniquement avec les membres déjà établis par la Party locale.

MISE À JOUR 1.5.41 — VALIDATEUR INSTALLATEUR
- Corrige le validateur Windows 1.5.40 qui recherchait encore le fragment de code de l’ancien fallback de notifications génériques.
- La validation contrôle maintenant la priorité du channel vaisseau partagé dans les deux chemins réellement utilisés : notifications locales whitelistées et événements distants chiffrés.
- Aucun changement de comportement : seules les notifications explicitement autorisées restent affichées ; la sortie de vaisseau affiche uniquement le nom du lieu.
- Build Public uniquement, sans RelayTest.

MISE À JOUR 1.5.40 — NOTIFICATIONS EN LISTE BLANCHE
- Le HUD Party n'affiche plus les notifications Star Citizen génériques, y compris sur le profil principal.
- Seuls les états explicitement définis par SC-RTLT restent affichés : lieu d'entrée/sortie d'armistice ; Departure/Landing ; Executing mission ; Missions accomplished ; Failed missions ; Incoming mission ; Incoming call (local uniquement) ; Regenerating ; état du channel vaisseau ; sortie vaisseau = lieu uniquement.
- Toute autre notification SHUDEvent_OnNotification est ignorée par l'affichage SC-RTLT et n'est jamais relayée comme activité générique.
- Build Public uniquement, sans RelayTest.

MISE À JOUR 1.5.39 — SORTIE VAISSEAU = LIEU UNIQUEMENT
- À la sortie d’un vaisseau, le profil principal affiche uniquement le nom du lieu pendant 10 secondes, puis revient au titre RSI. Aucun préfixe `ON FOOT` n’est ajouté.
- La même règle s’applique aux membres distants via le relais chiffré : `ship_leave` transporte le lieu déjà interprété par SC-RTLT et l’interface affiche uniquement ce lieu.
- Si aucun lieu fiable n’est disponible, SC-RTLT revient au titre au lieu d’inventer un état `ON FOOT`.
- Le build Public reste sans RelayTest ; une variante Test séparée de la même version est fournie pour les validations Cloudflare et Group UI.

MISE À JOUR 1.5.38 — SORTIE VAISSEAU LOCALE ROBUSTE
- Corrige les sessions Star Citizen 4.9 où aucune notification `You have left the channel ...` n’est écrite à la sortie du vaisseau.
- Quand un channel vaisseau reconnu est déjà actif, `CVehicleMovementBase::ClearDriver` devient un filet de sécurité seulement après une demande de hangar récente ; se lever du siège en vol ne ferme pas le contexte vaisseau. L’accès ASOP sert de confirmation de secours ; le replay de démarrage reste exclu.
- Le profil principal affichait un état de sortie temporaire ; la 1.5.39 le remplace par le lieu seul.
- Le même `ship_leave` digéré continue d’être chiffré/signé puis relayé aux autres membres SC-RTLT de la Party.
- RelayTest reste absent du build Public. Les tests relais doivent rester dans un build de test séparé afin de ne pas distribuer de profils synthétiques.

MISE À JOUR 1.5.37 — NOTIFICATIONS CHIFFRÉES PARTAGÉES
- Le protocole Cloudflare relaie maintenant les états déjà digérés : armistice/lieu, départ/atterrissage hangar, mission en cours/terminée/échouée, mission entrante et régénération, en plus des entrées/sorties de vaisseau et du propre handle↔GEID.
- Aucun texte brut de Game.log ou de notification HUD n'est envoyé. Le widget produit d'abord un type d'événement fermé puis le client chiffre/signe ce paquet.
- `INCOMING CALL` reste strictement local et n'existe pas dans la liste des événements réseau.
- Si plusieurs membres partagent le même channel de vaisseau, le contexte vaisseau reste prioritaire sur toutes les notifications distantes temporaires.
- Le Worker Cloudflare reste inchangé : il relaie des paquets opaques et ne possède aucune clé de déchiffrement.

MISE À JOUR 1.5.36 — BUILD PUBLIC / PRIORITÉ CHANNEL VAISSEAU
- Supprime complètement RelayTest du build public : aucun lanceur, module, room synthétique ni porte de test n'est distribué.
- `INCOMING CALL` est strictement local au joueur principal et n'est jamais transmis via Cloudflare.
- Quand au moins deux joueurs connus occupent le même channel de vaisseau, ce contexte de vaisseau devient prioritaire sur toutes leurs activités et alertes temporaires.
- Les événements réseau publics restent limités à `ship_enter`, `ship_leave` et `player_geid`, déjà chiffrés/signés.

MISE À JOUR 1.5.35 — NOTIFICATIONS CONTEXTUELLES
- Entrée/sortie d’armistice : le titre temporaire affiche le lieu courant du joueur, jamais le texte brut de l’armistice.
- Demande de hangar en vaisseau : `DEPARTURE FROM <lieu>` tant que le joueur n’a pas changé de lieu depuis l’entrée dans le channel, puis `LANDING AT <lieu>` après déplacement/quantum confirmé par le moteur de localisation.
- Première notification de mission : `EXECUTING MISSION`; fin : `MISSIONS ACCOMPLISHED`; échec : `FAILED MISSIONS`.
- Mission partagée ou appel entrant : portrait local remplacé 10 s par le signal 4 barres, nom `INCOMING MISSION` / `INCOMING CALL`, traits et signal teintés jaune/orange avec clignotement subtil.
- Mort du joueur local détectée via `<Actor Death> CActor::Kill` : `REGENERATING` pendant 10 s.
- Les événements restent lus localement depuis Game.log; seules les informations déjà digérées continuent d’être partagées par le relais chiffré.

MISE À JOUR 1.5.32 — VALIDATION INSTALLATEUR
- Corrige le validateur Windows resté sur l’ancienne interface du partage temps réel : il ne recherche plus la case `Enable encrypted real-time sharing` ni le bouton CONNECT supprimés en 1.5.31.
- La validation vérifie maintenant le comportement réel : relais Cloudflare par défaut, activation automatique du client au lancement, identité cryptographique persistante et absence des anciens contrôles manuels.
- La logique applicative du partage automatique et les protections anti-fantôme/WAITING restent celles de 1.5.31.


MISE À JOUR 1.5.31 — PARTAGE TEMPS RÉEL AUTOMATIQUE
- Le partage temps réel chiffré est désormais actif automatiquement dès le lancement de SC-RTLT : aucun clic, aucune case à cocher et aucun bouton CONNECT n'est nécessaire.
- La section Réglages > Partage temps réel — Alpha n'affiche plus que le Status et la description.
- Le relais public reste interne et fixé à https://sc-rtlt-realtime.scrtlt-relay.workers.dev.
- L'identité cryptographique locale est créée automatiquement si nécessaire puis protégée par Windows DPAPI ; le joueur n'a aucune clé à gérer.
- Tant qu'aucun autre membre SC-RTLT du groupe n'est disponible, le statut indique que le partage chiffré est prêt et attend des membres. Dès qu'une preuve Party locale permet une liaison, la connexion WebSocket chiffrée démarre automatiquement.
- Les protections anti-fantôme de 1.5.29/1.5.30 restent inchangées : le réseau ne peut pas créer un joueur absent des preuves Party locales.


MISE À JOUR 1.5.29 — PARTAGE AUTOMATIQUE + ANTI-FANTÔME
- Les réglages temps réel n'affichent plus l'adresse Cloudflare ni une clé/invitation : le relais public est fixé à https://sc-rtlt-realtime.scrtlt-relay.workers.dev et un bouton CONNECT déclenche la connexion.
- SC-RTLT génère automatiquement une identité cryptographique locale une seule fois. La clé privée de signature Ed25519 et la clé X25519 sont protégées par Windows DPAPI et réutilisées ; le joueur n'a rien à générer manuellement à chaque lancement.
- Les membres SC-RTLT se retrouvent automatiquement dans des rooms pair-à-pair opaques dérivées des preuves Party locales (handle ou GEID). Les contenus sont chiffrés en AES-256-GCM avec une clé issue de X25519/HKDF et chaque événement est signé Ed25519.
- Cloudflare reste un relais aveugle : aucun Game.log brut n'est envoyé et le Worker ne possède aucune clé de déchiffrement.
- Le propre handle/GEID peut être partagé dès qu'il est confirmé localement, pour résoudre plus vite un membre déjà prouvé par le Game.log du destinataire.
- `You have created party` / `You have joined party` ne créent plus et ne promeuvent plus de membre synthétique. Les WAITING FOR RESPONSE sont supprimés dès la confirmation locale de Party ; un membre distant n'apparaît ensuite que sur PartyMarker ou preuve Party nominative.
- WAITING FOR RESPONSE reste limité à 20 s avec un second nettoyage périodique de sécurité ; les invitations sortantes historiques ne sont plus rejouées au démarrage.
- Les associations GEID↔handle ne sont plus persistées entre Game.log/sessions afin d'éviter qu'un GEID réutilisé ou périmé ressuscite un joueur fantôme.


MISE À JOUR 1.5.28 — GEID CHIFFRÉ + INSTALLATEUR
- Corrige l'échec Windows PowerShell 5.1 observé juste après PyAudioWPatch : stderr de python/pip n'est plus traité comme un échec si le processus retourne le code 0.
- Quand SC-RTLT connaît son propre GEID de façon fiable, il partage son couple handle/GEID dans le même payload AES-256-GCM que les événements vaisseau.
- Un GEID reçu ne crée jamais de membre Party : il peut seulement résoudre un PartyMarker GEID déjà présent localement ou enrichir un handle Party déjà prouvé par le Game.log local.
- Une association GEID reçue du réseau reste temporaire et n'est pas persistée dans le cache d'identité fiable.
- Le Game.log brut reste entièrement local et n'est jamais transmis.

MISE À JOUR 1.5.27 — PARTAGE TEMPS RÉEL CHIFFRÉ
- Ajoute un partage temps réel optionnel entre utilisateurs SC-RTLT, sans compte utilisateur.
- Aucun Game.log ni ligne brute n’est envoyé : seuls les événements déjà interprétés d’entrée/sortie de vaisseau sont transmis.
- L’entrée dans un vaisseau est relayée à partir du changement de contexte de channel vaisseau déjà détecté par SC-RTLT.
- À la sortie du vaisseau, le lieu déjà interprété localement est envoyé avec l’événement ; le membre distant affiche le lieu pendant 10 s puis revient à son titre RSI.
- Le channel de vaisseau garde la priorité tant qu’il est actif.
- Les messages sont chiffrés localement en AES-256-GCM avant le WebSocket WSS ; le relais Cloudflare ne reçoit pas la clé de chiffrement.
- La clé de l’invitation est protégée localement par Windows DPAPI.
- Le partage est désactivé par défaut. Cloudflare ne peut pas créer de joueur : un événement reçu s’applique seulement à un handle déjà présent dans le Group UI local.


MISE À JOUR 1.5.26 — SORTIE DE CHANNEL VAISSEAU
- La notification de sortie d’un channel de vaisseau reconnu n’est plus affichée comme activité temporaire.
- À la sortie du channel, le texte revient immédiatement au titre RSI du joueur, sans attendre 10 s.
- Une ancienne activité encore mémorisée est effacée au moment du départ du vaisseau afin qu’elle ne réapparaisse pas.
- La correction s’applique au joueur local et aux membres Party identifiés ; l’icône du titre reste inchangée.
- Les channels personnalisés/non-vaisseau restent traités normalement.

MISE À JOUR 1.5.25 — FILTRE ZONES D’ARMISTICE
- Les notifications d’entrée et de sortie de zone d’armistice ne remplacent plus le texte du titre.
- Elles restent disponibles pour la logique interne de localisation et d’arrivée.
- Toutes les autres activités 1.5.24 restent inchangées : affichage 10 s, rappel au survol, priorité vaisseau et icône RSI fixe.

MISE À JOUR 1.5.24 — ACTIVITÉ DANS LE TEXTE DU TITRE
- Le texte du titre du joueur local affiche pendant 10 s chaque nouvelle activité HUD détectée dans Game.log, puis revient au titre RSI.
- Le survol passif du bloc joueur rappelle la dernière activité récente sans prendre la souris au jeu.
- Le canal de vaisseau actif a toujours priorité sur l’activité et sur le titre RSI jusqu’à la sortie du canal.
- L’icône/badge du titre RSI ne change jamais : seul le texte du titre est remplacé.
- Même logique pour les membres Party déjà identifiés : leurs notifications nommées alimentent leur propre texte de titre pendant 10 s.
- Les notifications sans handle sont attribuées uniquement au joueur local ; aucun joueur distant n’est inventé.


MISE À JOUR 1.5.10 — PARTY INVITE FALLBACK
- Corrige le joueur fantôme WAITING FOR RESPONSE / WAITING FOR IDENTITY observé après certaines invitations Party.
- « You have created party » et « You have joined party » confirment uniquement la Party locale : ils ne créent plus de membre distant synthétique.
- Un membre distant sans nom est créé seulement lorsqu'un PartyMarker distant réel fournit son GEID.
- Si un WAITING FOR RESPONSE existe au moment où ce PartyMarker arrive, ce même slot est promu en WAITING FOR IDENTITY au lieu d'ajouter une seconde ligne.
- Les événements Party nommés et les invitations entrantes nommées continuent de résoudre immédiatement le joueur quand Star Citizen fournit son handle.
- Une dissolution/sortie Party efface toujours le roster visible de cette génération ; le cache GEID↔handle reste uniquement une mémoire d'identité.
- Si la page RSI publique masque ou redacte l'organisation principale, SC-RTLT affiche désormais ni nom de guilde ni logo.
- Le cache de profils RSI passe en v9 afin d'invalider les anciennes données d'organisation potentiellement conservées avant ce correctif.
- Le nettoyage du HTML RSI de la 1.5.6 est conservé : aucun fragment <DIV>, class=, href=, etc. ne doit être affiché dans le HUD.
- Le correctif d'installation 1.5.7 est conservé.

CONFIDENTIALITÉ DU BUILD
- Aucun Game.log réel, pseudo réel, GEID réel, identifiant de session, e-mail, token, chemin personnel ou IP personnelle n'est embarqué dans le build.
- Les validations distribuées utilisent uniquement des joueurs et identifiants synthétiques.
- Game.log est lu localement et en lecture seule à l'exécution.

IMPACT FONCTIONNEL
- Party HUD, WAITING FOR RESPONSE, WAITING FOR IDENTITY, RAID, détection véhicule, couleurs HUD et enrichissement RSI restent actifs.
- Les PartyMarkers déterminent la cardinalité distante ; les associations GEID↔handle restent limitées à la session courante et peuvent être enrichies par les pairs SC-RTLT chiffrés.
- Les profils RSI sans organisation publique restent volontairement vides pour la guilde.

INSTALLATION
1. Extraire complètement le ZIP.
2. Ouvrir le dossier SC-RTLT_Public_1.5.29.
3. Lancer Setup.bat.
4. Utiliser Launcher.vbs ou les raccourcis créés par l'installateur pour démarrer SC-RTLT Public.

HISTORIQUE RÉCENT
1.5.7 : corrige la validation de l'installateur Windows après le passage du cache RSI v7 au cache v8.
1.5.6 : nettoie les fragments HTML encodés des profils RSI.
1.5.5 : supprime un WAITING FOR IDENTITY résiduel quand le vrai joueur est déjà affiché puis confirmé par GEID/leadership.
1.5.4 : résout un WAITING synthétique lorsqu'un GEID déjà connu réapparaît.
1.5.3 : première tentative de reconstruction sans identité ; sa création synthétique trop précoce est remplacée par la logique PartyMarker de la 1.5.8.
1.5.2 : conserve le nom d'une invitation Party entrante pendant le replay du Game.log.

SC-RTLT Public est un outil communautaire non officiel pour Star Citizen.

1.5.9 : réduction du halo blanc des vignettes des joueurs du groupe.

1.5.10 : `You have created party` crée un WAITING FOR RESPONSE de secours (20 s) quand le signal technique d’invitation manque ; aucun WAITING FOR IDENTITY n’est inventé.

1.5.12 : "You have created party" confirme désormais un membre distant accepté : un WAITING FOR RESPONSE est promu en WAITING FOR IDENTITY sans timeout. Les invitations WAITING FOR RESPONSE sont exclues du seuil RAID ; seuls les membres distants prouvés comptent.

1.5.16 : portraits local + Group à 87 %, halo blanc fortement atténué et vignette noire directement superposée aux bords internes.
1.5.19 : suppression des effets avatar (halo noir, halo interne, balayage CRT, anneau dégradé) ; portraits local et Group à 100 % d'opacité fixe.

1.5.21 : avatars local et Group avec CRT seul et opacité 99 % → 94 % en 10 s → 99 % en 10 s ; aucun halo noir/interne.

1.5.23 : effet glitch/displacement sur les portraits local et Group à partir de la texture fournie, flash bref avec cooldown 7–20 s ; CRT conservé ; portraits opaques à 100 %.

1.5.24 : texte de titre contextuel pour activités HUD ; durée 10 s, rappel au survol, canal de vaisseau prioritaire et badge RSI inchangé.

1.5.25 : exclut les notifications d’entrée/sortie de zone d’armistice du texte d’activité temporaire sans toucher à la logique de localisation.

1.5.26 : sortie d’un channel de vaisseau exclue des activités temporaires ; retour immédiat au titre RSI.

1.5.27 : partage temps réel chiffré optionnel via Cloudflare ; aucun Game.log transmis, sortie de vaisseau + lieu affichés 10 s chez les membres Party déjà identifiés.

1.5.28 : partage chiffré du propre handle/GEID + correctif PowerShell 5.1 de l'installation cryptography.

1.5.29 : partage temps réel automatique sans champs de clé/serveur, signatures Ed25519 + X25519/HKDF, anti-fantôme Party et WAITING FOR RESPONSE renforcé.
