from __future__ import annotations

import json
import os
from importlib.resources import files
from pathlib import Path
import sys
import tempfile
import traceback

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
os.environ.setdefault("QT_LOGGING_RULES", "qt.multimedia.ffmpeg=false")
os.environ.setdefault("QTWEBENGINE_CHROMIUM_FLAGS", "--disable-gpu --no-sandbox")


def stage(name: str) -> None:
    print(f"[VERIFY] {name}", flush=True)


def fail(exc: BaseException) -> None:
    print(f"[VERIFY][FAIL] {type(exc).__name__}: {exc}", file=sys.stderr, flush=True)
    traceback.print_exc(file=sys.stderr)


def method_block(source: str, method_name: str) -> str:
    """Return one class method without depending on the following method name."""
    marker = f"    def {method_name}("
    start = source.index(marker)
    next_method = source.find("\n    def ", start + len(marker))
    end = len(source) if next_method < 0 else next_method + 1
    return source[start:end]


try:
    stage("Runtime Qt + cryptography")
    import PySide6
    from PySide6.QtCore import QSettings
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer  # noqa: F401
    from PySide6.QtWebEngineCore import QWebEngineProfile, QWebEngineSettings  # noqa: F401
    from PySide6.QtWebEngineWidgets import QWebEngineView  # noqa: F401
    from PySide6.QtWebSockets import QWebSocket  # noqa: F401
    from PySide6.QtWidgets import QApplication
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM

    stage("Import SC-RTLT Public")
    import sc_web_companion
    from sc_web_companion.party_context import HudNotificationActivityParser, PartyContextParser
    from sc_web_companion.realtime_share import (
        DEFAULT_REALTIME_ENDPOINT,
        DeviceIdentity,
        _REALTIME_CONSENT_VERSION,
        _PeerChannel,
        _derive_pair_key,
        _event_payload,
        _pair_room,
        ensure_realtime_defaults,
        load_or_create_device_identity,
        RealtimeShareClient,
    )
    from sc_web_companion.rsi_profile import parse_citizen_organizations_html
    from sc_web_companion.vehicle_palette import VehicleContextParser, manufacturer_from_channel_name
    from sc_web_companion.widget_window import PartyHudBlock
    import sc_web_companion.settings_page  # noqa: F401
    import sc_web_companion.widget_window  # noqa: F401
    import sc_web_companion.game_log_location  # noqa: F401
    from sc_web_companion.game_log_location import GameLogLocationMonitor, GameLogLocationParser

    expected_version = sys.argv[1] if len(sys.argv) > 1 else ""
    if not expected_version:
        raise RuntimeError("Version attendue absente de la commande de validation.")
    if sc_web_companion.__version__ != expected_version:
        raise RuntimeError(
            f"Version installee incorrecte : {sc_web_companion.__version__!r}, attendu {expected_version!r}."
        )

    stage("Localisation villes prioritaires 2.1.17")
    city_regressions = (
        ("RR_HUR_LEO", "Lorville_loc", "Lorville", "Everus Harbor"),
        ("RR_MIC_LEO", "NewBabbage_loc", "New Babbage", "Port Tressler"),
        ("RR_ARC_LEO", "Area18_loc", "Area18", "Baijini Point"),
        ("RR_CRU_LEO", "Orison_loc", "Orison", "Seraphim Station"),
    )
    for station_code, city_token, expected_city, station_name in city_regressions:
        parser = GameLogLocationParser()
        station_update = parser.parse_update(
            f'<2099-01-01T00:00:00.000Z> [Notice] LocationManager: LocationManager_{station_code}'
        )
        if station_update is None or station_update.detection.name != station_name:
            raise RuntimeError(f"Station orbitale synthetique non reconnue : {station_code}")
        city_update = parser.parse_update(
            f'<2099-01-01T00:00:01.000Z> [Notice] <RequestLocationInventory> '
            f'Player[Player_A] requested inventory for Location[{city_token}]'
        )
        if (
            city_update is None
            or not city_update.confirmed
            or city_update.detection.name != expected_city
        ):
            got = city_update.detection.name if city_update is not None else "<aucune>"
            raise RuntimeError(
                f"Regression ville/station : {expected_city} reste remplacee par {got!r}."
            )

    # A generic planetary LocationManager token is context, never proof that the
    # player is physically at the corresponding low-orbit station.
    for body_code in ("Stanton_1", "Stanton_2", "Stanton_3", "Stanton_4"):
        parser = GameLogLocationParser()
        update = parser.parse_update(
            f'<2099-01-01T00:00:02.000Z> [Notice] LocationManager: LocationManager_{body_code}'
        )
        if update is not None and "station" in update.detection.location_type.casefold():
            raise RuntimeError(
                f"Token planetaire {body_code} promu a tort en station : {update.detection.name}"
            )

    stage("Partage chiffre + consentement 2.1.2")
    if DEFAULT_REALTIME_ENDPOINT != "https://sc-rtlt-realtime.scrtlt-relay.workers.dev":
        raise RuntimeError("Relais Cloudflare public par defaut incorrect.")
    identity_a = DeviceIdentity.generate()
    identity_b = DeviceIdentity.generate()
    room_ab = _pair_room("h", "Player_A", "Player_B")
    room_ba = _pair_room("h", "Player_B", "Player_A")
    if room_ab != room_ba or not room_ab:
        raise RuntimeError("Rendez-vous pair-a-pair non deterministe.")
    key_a = _derive_pair_key(identity_a, identity_b.exchange_public, room_ab)
    key_b = _derive_pair_key(identity_b, identity_a.exchange_public, room_ab)
    if key_a != key_b or len(key_a) != 32:
        raise RuntimeError("X25519/HKDF ne produit pas une cle AES-256 commune.")
    payload = _event_payload(
        "ship_leave",
        "Player_A",
        location="Synthetic Station",
        message_id="synthetic-message-0001",
    )
    plaintext = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    nonce = bytes(range(12))
    aad = b"SC-RTLT-VERIFY-v3"
    encrypted = AESGCM(key_a).encrypt(nonce, plaintext, aad)
    if b"Player_A" in encrypted or b"Synthetic Station" in encrypted:
        raise RuntimeError("Donnee metier visible en clair dans le paquet chiffre.")
    decoded = json.loads(AESGCM(key_b).decrypt(nonce, encrypted, aad).decode("utf-8"))
    if decoded.get("event") != "ship_leave" or decoded.get("actor") != "Player_A":
        raise RuntimeError("Dechiffrement pair-a-pair incorrect.")
    semantic_cases = (
        ("armistice_location", "Synthetic Station"),
        ("hangar_departure", "Synthetic Station"),
        ("hangar_landing", "Synthetic Destination"),
        ("mission_execute", ""),
        ("mission_complete", ""),
        ("mission_failed", ""),
        ("incoming_mission", ""),
        ("regenerating", ""),
    )
    for index, (event_name, event_location) in enumerate(semantic_cases):
        semantic = _event_payload(
            event_name,
            "Player_A",
            location=event_location,
            message_id=f"synthetic-semantic-{index:04d}",
        )
        if semantic.get("event") != event_name:
            raise RuntimeError(f"Evenement semantique invalide : {event_name}")
    try:
        _event_payload("incoming_call", "Player_A", message_id="synthetic-local-only-0001")
    except ValueError:
        pass
    else:
        raise RuntimeError("INCOMING CALL est accepte par le protocole alors qu'il doit rester local.")
    signed = b"synthetic-signed-event"
    signature = identity_a.signing.sign(signed)
    identity_a.signing.public_key().verify(signature, signed)

    stage("Cle locale automatique + migration des anciens champs")
    with tempfile.TemporaryDirectory(prefix="sc-rtlt-realtime-") as temp_dir:
        settings = QSettings(str(Path(temp_dir) / "settings.ini"), QSettings.Format.IniFormat)
        settings.setValue("realtime/room_id", "legacy-room")
        settings.setValue("realtime/invite_plain", "legacy-secret")
        settings.setValue("realtime/enabled", True)
        ensure_realtime_defaults(settings)
        if settings.value("realtime/endpoint", "", type=str) != DEFAULT_REALTIME_ENDPOINT:
            raise RuntimeError("Le relais public n'est pas memorise par defaut.")
        if settings.value("realtime/enabled", True, type=bool):
            raise RuntimeError("Le partage temps reel doit etre OFF sans consentement explicite.")
        settings.setValue("realtime/consent_version", _REALTIME_CONSENT_VERSION)
        settings.setValue("realtime/enabled", True)
        ensure_realtime_defaults(settings)
        if not settings.value("realtime/enabled", False, type=bool):
            raise RuntimeError("Le partage consenti ne peut pas etre active.")
        for legacy in ("realtime/room_id", "realtime/invite_plain", "realtime/invite_protected"):
            if settings.contains(legacy):
                raise RuntimeError(f"Ancien champ manuel encore conserve : {legacy}")
        first = load_or_create_device_identity(settings)
        second = load_or_create_device_identity(settings)
        if first.signing_public != second.signing_public or first.exchange_public != second.exchange_public:
            raise RuntimeError("SC-RTLT regenere ses cles a chaque chargement.")
        client = RealtimeShareClient(settings)
        try:
            if not client._enabled:
                raise RuntimeError("Le client temps reel n'est pas actif quand l'option est ON.")
            client.set_local_handle("Player_A")
            hello_channel = _PeerChannel(
                client,
                channel_key="h:player_b",
                mode="h",
                peer_id="Player_B",
                room_id=_pair_room("h", "Player_A", "Player_B"),
            )
            hello = hello_channel._hello_body()
            if any(key in hello for key in ("actor", "geid", "mode")):
                raise RuntimeError("Le HELLO expose encore une identite Party ou le mode de rendez-vous.")
            hello_text = json.dumps(hello, sort_keys=True)
            if "Player_A" in hello_text or "Player_B" in hello_text:
                raise RuntimeError("Le HELLO expose encore un handle RSI en clair.")
            hello_channel.stop()
            hello_channel.deleteLater()
            if settings.value("realtime/endpoint", "", type=str) != DEFAULT_REALTIME_ENDPOINT:
                raise RuntimeError("Le client temps reel n'utilise pas le relais public par defaut.")
            settings.setValue("realtime/enabled", False)
            client.reconfigure()
            if client._enabled or client._channels:
                raise RuntimeError("Le partage OFF ne ferme pas completement les liaisons temps reel.")
            settings.setValue("realtime/enabled", True)
            client.reconfigure()
            if not client._enabled:
                raise RuntimeError("Le partage ne peut pas etre reactive depuis les reglages.")
        finally:
            client.shutdown()

    stage("Evenements vaisseau live")
    vehicle_parser = VehicleContextParser()
    join_update = vehicle_parser.parse_line(
        '<2099-01-01T00:00:00.000Z> <SHUDEvent_OnNotification> Added notification "You have joined channel \'Aegis Ares Inferno : Player_A\'."'
    )
    leave_update = vehicle_parser.parse_line(
        '<2099-01-01T00:00:01.000Z> <SHUDEvent_OnNotification> Added notification "You have left the channel \'Aegis Ares Inferno : Player_A\'."'
    )
    restart_leave = VehicleContextParser().parse_line(
        '<2099-01-01T00:00:02.000Z> <SHUDEvent_OnNotification> Added notification "You have left the channel \'Aegis Ares Inferno : Player_A\'."'
    )
    if join_update is None or join_update.event != "ship_enter":
        raise RuntimeError("Entree de channel vaisseau non detectee.")
    if leave_update is None or leave_update.event != "ship_leave":
        raise RuntimeError("Sortie de channel vaisseau non detectee.")
    if restart_leave is None or restart_leave.event != "ship_leave":
        raise RuntimeError("Sortie live perdue apres redemarrage de SC-RTLT.")
    fallback_parser = VehicleContextParser()
    fallback_join = fallback_parser.parse_line(
        "<2099-01-01T00:00:03.000Z> <SHUDEvent_OnNotification> Added notification \"You have joined channel 'Anvil Terrapin Medic : Player_A'.\""
    )
    fallback_parser.parse_line(
        '<2099-01-01T00:00:03.500Z> <SHUDEvent_OnNotification> Added notification "Hangar Request Completed: "'
    )
    fallback_leave = fallback_parser.parse_line(
        "<2099-01-01T00:00:04.000Z> [Notice] <Vehicle Control Flow> CVehicleMovementBase::ClearDriver: Local client node [990000000001] releasing control token for 'ANVL_Terrapin_Medic_990000000002' [990000000002] [Team_CGP4][Vehicle]"
    )
    if fallback_join is None or fallback_join.event != "ship_enter":
        raise RuntimeError("Preparation du fallback ClearDriver impossible.")
    if fallback_leave is None or fallback_leave.event != "ship_leave":
        raise RuntimeError("ClearDriver live ne ferme pas le contexte vaisseau.")
    flight_parser = VehicleContextParser()
    flight_parser.parse_line(
        "<2099-01-01T00:00:05.000Z> <SHUDEvent_OnNotification> Added notification \"You have joined channel 'Anvil Terrapin Medic : Player_A'.\""
    )
    false_leave = flight_parser.parse_line(
        "<2099-01-01T00:00:06.000Z> [Notice] <Vehicle Control Flow> CVehicleMovementBase::ClearDriver: Local client node [990000000001] releasing control token for 'ANVL_Terrapin_Medic_990000000002' [990000000002] [Team_CGP4][Vehicle]"
    )
    if false_leave is not None:
        raise RuntimeError("ClearDriver en vol provoque une fausse sortie vaisseau.")

    stage("Notifications contextuelles 2.1.2")
    activity_parser = HudNotificationActivityParser()
    armistice_body = activity_parser.parse_line(
        '<2099-01-01T00:00:03.000Z> <SHUDEvent_OnNotification> Added notification "Entering Armistice Zone" [42] to queue.'
    )
    if armistice_body != "Entering Armistice Zone":
        raise RuntimeError("Notification armistice non transmise au mapper contextuel.")

    stage("Party parser + anti-fantome 2.1.2")
    party_parser = PartyContextParser()
    outgoing = party_parser.parse_line(
        "[Notice] <InviteMembersToGroup Start> Inviting members to group 00000000-0000-0000-0000-000000000000"
    )
    if outgoing is None or outgoing.kind != "outgoing_invite":
        raise RuntimeError("Invitation Party sortante non detectee.")

    # 2.1.8: after a named incoming invite is accepted, SC 4.9 requests the
    # remote player's instance info by GEID before the PU transition. This exact
    # GEID event lets the widget preserve the already-known identity even if a
    # contradictory frontend Party Disbanded notification follows.
    incoming = party_parser.parse_line(
        '<2099-01-01T00:00:10.000Z> Player_B Party Invite Received: Accept Invitation?: " [24] to queue.'
    )
    if incoming is None or incoming.kind != "incoming_invite" or incoming.handle != "Player_B":
        raise RuntimeError("Invitant Party nomme non detecte.")
    accepted = party_parser.parse_line(
        "[Notice] <Accept invitation> Client 100000000001 accept invitation 11111111-2222-3333-4444-555555555555"
    )
    if accepted is None or accepted.kind != "incoming_invite_accepted" or accepted.ship_name != "100000000001":
        raise RuntimeError("Acceptation Party entrante non detectee.")
    remote_instance = party_parser.parse_line(
        "[Notice] <Get player instance info> Request instance info for player 100000000002 [Team_GameServices][Social]"
    )
    if remote_instance is None or remote_instance.kind != "player_instance_geid" or remote_instance.ship_name != "100000000002":
        raise RuntimeError("GEID instance-info distant non detecte apres acceptation Party.")

    stage("Preuves Party locales non-RTLT 2.1.14")
    named_party_cases = (
        (
            'Player_C is sharing a mission',
            "member_confirmed",
            "Player_C",
        ),
        (
            'Player Connected Player_D',
            "member_connected",
            "Player_D",
        ),
        (
            'Quantum Linking: QT for the group - Initiated by Player_E',
            "member_confirmed",
            "Player_E",
        ),
        (
            'Player_F initiated QT jump for the group',
            "member_confirmed",
            "Player_F",
        ),
    )
    for index, (body, expected_kind, expected_handle) in enumerate(named_party_cases, start=70):
        parser = PartyContextParser()
        event = parser.parse_line(
            f'<2099-01-01T00:01:{index - 70:02d}.000Z> [Notice] '
            f'<SHUDEvent_OnNotification> Added notification "{body}" [{index}] to queue. New queue size: 1'
        )
        if event is None or event.kind != expected_kind or event.handle != expected_handle:
            raise RuntimeError(
                f"Preuve Party nommee mal classee : {body!r} -> {event!r}"
            )

    for index, body in enumerate((
        'Quantum Linking: QT for the group',
        'Party Launching: Join Party In PU? - Initiated by Player_G',
        "Player_H joined the group 'Nehhs Channels'",
    ), start=80):
        parser = PartyContextParser()
        event = parser.parse_line(
            f'<2099-01-01T00:02:{index - 80:02d}.000Z> [Notice] '
            f'<SHUDEvent_OnNotification> Added notification "{body}" [{index}] to queue. New queue size: 1'
        )
        if event is not None:
            raise RuntimeError(f"Faux membre Party cree par notification non probante : {body!r} -> {event!r}")

    stage("Exception hangar queue 2.1.20")
    # Exact SC 4.9 multiline cargo/ATC notification observed in the user's
    # Game.log. It previously became `member_connected / hangar`.
    parser = PartyContextParser()
    hangar_start = parser.parse_line(
        '<2099-01-01T00:02:30.000Z> [Notice] <SHUDEvent_OnNotification> Added notification "Joined hangar queue.\n'
    )
    hangar_end = parser.parse_line(
        '<2099-01-01T00:02:30.000Z> Your place: 1. Max. estimated wait: 100.000000 s.: " [89] to queue. New queue size: 1'
    )
    if hangar_start is not None or hangar_end is not None:
        raise RuntimeError(f"Hangar queue cree encore un faux membre Party : {hangar_start!r} / {hangar_end!r}")
    real_hangar_player = PartyContextParser().parse_line(
        '<2099-01-01T00:02:31.000Z> [Notice] <SHUDEvent_OnNotification> Added notification "Hangar connected" [90] to queue. New queue size: 1'
    )
    if real_hangar_player is None or real_hangar_player.kind != "member_connected" or real_hangar_player.handle != "Hangar":
        raise RuntimeError("L'exception hangar queue bloque un vrai handle Hangar.")

    # Exact SC 4.9 multiline presence notification observed in Game.log.
    parser = PartyContextParser()
    if parser.parse_line(
        '<2099-01-01T00:03:00.000Z> [Notice] <SHUDEvent_OnNotification> Added notification "Party\n'
    ) is not None:
        raise RuntimeError("Notification Party multiligne terminee trop tot.")
    connected = parser.parse_line(
        '<2099-01-01T00:03:00.000Z> Player_I connected.: " [90] to queue. New queue size: 1'
    )
    if connected is None or connected.kind != "member_connected" or connected.handle != "Player_I":
        raise RuntimeError("Forme reelle Party / <handle> connected non detectee.")

    parser = PartyContextParser()
    mission_owner = parser.parse_line(
        '<2099-01-01T00:03:01.000Z> [Notice] <MissionShared> Received share push message: ownerId[100000000009] - missionId[11111111-2222-3333-4444-555555555555]'
    )
    if mission_owner is None or mission_owner.kind != "member_geid_confirmed" or mission_owner.ship_name != "100000000009":
        raise RuntimeError("MissionShared ownerId GEID non detecte comme membre Party.")

    parser = PartyContextParser()
    # 2.1.14: both historical RelayTest markers (no marker id) and current SC
    # markers (with marker id) must remain valid Party-cardinality evidence.
    legacy_marker = parser.parse_line(
        '<2099-01-01T00:03:01.500Z> [Notice] <CPartyMarkerComponent RWES> Streamed in party marker TrackedEntityId: 100000000008'
    )
    if legacy_marker is None or legacy_marker.kind != "party_marker" or legacy_marker.ship_name != "100000000008":
        raise RuntimeError("Ancien PartyMarker RelayTest sans marker id non detecte.")

    parser = PartyContextParser()
    marker = parser.parse_line(
        '<2099-01-01T00:03:02.000Z> [Notice] <CPartyMarkerComponent RWES> Streamed in party marker id 700000000001. TrackedEntityId: 100000000010'
    )
    qt = parser.parse_line(
        '<2099-01-01T00:03:03.000Z> [Notice] <Player Requested Fuel to Quantum Target - Local> target PartyMemberMarker_700000000001'
    )
    if marker is None or marker.kind != "party_marker" or marker.ship_name != "100000000010":
        raise RuntimeError("PartyMarker marker->GEID non detecte.")
    if qt is None or qt.kind != "member_geid_confirmed" or qt.ship_name != "100000000010":
        raise RuntimeError("QT PartyMemberMarker ne confirme pas le GEID du membre.")

    parser = PartyContextParser()
    parser.parse_line(
        '<2099-01-01T00:03:04.000Z> [Notice] <SHUDEvent_OnNotification> Added notification "Party Disbanded\n'
    )
    disband = parser.parse_line(
        '<2099-01-01T00:03:04.000Z> The party has been disbanded.: " [93] to queue. New queue size: 1'
    )
    parser.parse_line(
        '<2099-01-01T00:03:04.050Z> [Notice] <SHUDEvent_OnNotification> Added notification "You have created\n'
    )
    transition = parser.parse_line(
        '<2099-01-01T00:03:04.050Z> party: " [94] to queue. New queue size: 2'
    )
    if disband is None or disband.kind != "party_disbanded":
        raise RuntimeError("Party Disbanded de transition non detecte.")
    if transition is None or transition.kind != "local_party_transition":
        raise RuntimeError("Frontend->PU Party Disbanded/Create non classe en transition.")

    package_root = files("sc_web_companion")
    settings_source = package_root.joinpath("settings_page.py").read_text(encoding="utf-8")
    realtime_source = package_root.joinpath("realtime_share.py").read_text(encoding="utf-8")
    widget_source = package_root.joinpath("widget_window.py").read_text(encoding="utf-8")
    game_log_source = package_root.joinpath("game_log_location.py").read_text(encoding="utf-8")
    party_source = package_root.joinpath("party_context.py").read_text(encoding="utf-8")

    for fragment in (
        'kind in {"member_join", "party_leader", "member_connected", "member_confirmed"}',
        'kind == "member_geid_confirmed"',
        'elif kind == "member_disconnected" and handle:',
        '"local_party_transition"',
        '_MAX_PARTY_RECOVERY_BYTES = 128 * 1024 * 1024',
    ):
        if fragment not in widget_source and fragment not in game_log_source:
            raise RuntimeError(f"Promotion Party des notifications nommees incomplete : {fragment}")
    for fragment in (
        '_authoritative_member_event_from_notification',
        '_MISSION_SHARE_MEMBER_PATTERNS',
        '_QT_NAMED_BY_RE',
        '_PARTY_LAUNCH_CONTEXT_RE',
        '_MISSION_SHARED_OWNER_RE',
        '_PARTY_QT_MARKER_RE',
    ):
        if fragment not in party_source:
            raise RuntimeError(f"Parseur de preuve Party nommee incomplet : {fragment}")

    stage("Compatibilite Game.log externe 2.1.14")
    # Replay classification is semantic now: only canonical RSI runtime logs are
    # non-replayed. Old/renamed RelayTest files and manually selected fixtures work.
    for external_path in (
        Path(r"C:\Tests\RelayTest\Data\Game.log"),
        Path(r"C:\Tests\RelayWidgetTest_Game.log"),
        Path(r"C:\QA\Game.log"),
        Path(r"C:\QA\renamed_fixture.log"),
    ):
        if not GameLogLocationMonitor._is_external_test_log(external_path):
            raise RuntimeError(f"Journal manuel/externe non rejouable : {external_path}")
    for runtime_path in (
        Path(r"C:\Program Files\Roberts Space Industries\StarCitizen\LIVE\Game.log"),
        Path(r"D:\Games\StarCitizen\PTU\Game.log"),
        Path(r"E:\StarCitizen\TECH-PREVIEW\Game.log"),
    ):
        if GameLogLocationMonitor._is_external_test_log(runtime_path):
            raise RuntimeError(f"Vrai Game.log RSI classe a tort comme replay externe : {runtime_path}")
    for fragment in (
        '_MAX_EXTERNAL_TEST_REPLAY_BYTES = 128 * 1024 * 1024',
        'def _is_star_citizen_runtime_log(path: Path) -> bool:',
        'def _is_external_test_log(cls, path: Path) -> bool:',
        'def _replay_external_log(self, handle: BinaryIO, file_size: int) -> None:',
        'def _continuity_intact(self, file_size: int) -> bool:',
        'self._replay_external_log(handle, stat.st_size)',
    ):
        if fragment not in game_log_source:
            raise RuntimeError(f"Compatibilite Game.log externe incomplete : {fragment}")

    main_window_source = package_root.joinpath("main_window.py").read_text(encoding="utf-8")

    for fragment in (
        'set_special_alert(local_handle, "INCOMING MISSION")',
        'set_special_alert(local_handle, "INCOMING CALL")',
        'f"Landing at {location}" if self._local_ship_moved_since_join else f"Departure from {location}"',
        'set_activity(local_handle, "Missions accomplished")',
        'set_activity(local_handle, "Failed missions")',
        'set_activity(local_handle, "Executing mission")',
        'set_activity(local_handles[0], "Regenerating")',
        '_PARTY_PROFILE_PLACEHOLDER) if special_alert else',
        '_active_alert_color()',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Notification contextuelle incomplete : {fragment}")
    if 'self.widget_window.set_current_player_location(name, body, raw_location)' not in main_window_source:
        raise RuntimeError("Le widget ne recoit pas le lieu courant pour les notifications contextuelles.")
    if 'self.game_log_monitor.vehicle_event.connect(self.widget_window.handle_local_vehicle_event)' not in main_window_source:
        raise RuntimeError("La sortie vaisseau locale n'est pas reliee au profil principal.")
    if 'def handle_local_vehicle_event' not in widget_source or 'def _restore_local_title_after_ship_leave(self) -> None:' not in widget_source:
        raise RuntimeError("Restauration du titre local apres sortie vaisseau incomplete.")
    if 'f"ON FOOT · {location}"' in widget_source or 'f"ON FOOT · {clean_location}"' in widget_source:
        raise RuntimeError("Le prefixe ON FOOT ne doit plus etre ajoute a ship_leave.")
    if '_CLEAR_DRIVER_RE' not in package_root.joinpath("vehicle_palette.py").read_text(encoding="utf-8"):
        raise RuntimeError("Fallback ClearDriver absent du parseur vaisseau.")
    if '_LOCAL_ACTOR_DEATH_RE' not in game_log_source or '("local_death", "", "")' not in game_log_source:
        raise RuntimeError("Detection de mort locale incomplete.")

    stage("UI temps reel avec consentement 2.1.2")
    for fragment in (
        'self.realtime_enabled = QPushButton()',
        'self.realtime_enabled.setCheckable(True)',
        'self.settings.value("realtime/enabled", False, type=bool)',
        'self.realtime_enabled.toggled.connect(self._apply_realtime_sharing_live)',
        'self.realtime_status = QLabel(',
        'def _confirm_realtime_consent(self) -> bool:',
        'J’ACCEPTE — ACTIVER',
        'I AGREE — ENABLE',
        'SC-RTLT n’inclut pas votre adresse IP dans les données de jeu partagées',
        'SC-RTLT does not include your IP address in the shared gameplay data',
        'realtime/consent_last_accepted_utc',
        'realtime_form.addRow(self.realtime_enabled)',
        'realtime_form.addRow(t("État", "Status"), self.realtime_status)',
        'self._section(t("Partage temps réel — Alpha", "Real-time sharing — Alpha"), realtime_form)',
        'self.settings.setValue("realtime/enabled", self.realtime_enabled.isChecked())',
    ):
        if fragment not in settings_source:
            raise RuntimeError(f"Reglage temps reel incomplet : {fragment}")
    for forbidden in (
        'self.realtime_connect_button = QPushButton',
        'Group invitation',
        'Create invitation',
        'Copy invitation',
        'self.realtime_endpoint = QLineEdit',
        'self.realtime_invite = QLineEdit',
    ):
        if forbidden in settings_source:
            raise RuntimeError(f"Ancien controle temps reel encore visible : {forbidden}")
    if 'self.realtime_share = RealtimeShareClient(self.settings, self)' not in main_window_source:
        raise RuntimeError("Le client temps reel n'est pas cree au lancement.")
    for fragment in (
        'consent_version != _REALTIME_CONSENT_VERSION',
        'self._enabled = self.settings.value("realtime/enabled", False, type=bool)',
        'if not self._enabled:\n            self._drop_all_channels()',
        'RSI handle/GEID are sent only after X25519 establishes the encrypted channel.',
        'if channel.mode == "g" and not channel._identity_confirmed:',
    ):
        if fragment not in realtime_source:
            raise RuntimeError(f"Interrupteur temps reel non respecte par le client : {fragment}")

    for fragment in (
        'Ed25519PrivateKey.generate()',
        'X25519PrivateKey.generate()',
        'SC-RTLT-EVENT-SIG-v3',
        'AESGCM(key)',
        'self.remote_identity.emit(actor, geid)',
        'QTimer.singleShot(0, lambda: self._broadcast_event("ship_leave", location=self._last_location))',
        'self._hello_response_sent = False',
        'if not self._hello_response_sent:',
        'self._hello_response_sent = True',
        'self._send_hello()',
        '"player_location", self._local_handle, location=self._last_location',
    ):
        if fragment not in realtime_source:
            raise RuntimeError(f"Partage chiffre/signature incomplet : {fragment}")



    stage("Build public sans RelayTest + priorite vaisseau partage")
    for forbidden in (
        "relay_test",
        "RELAY_TEST",
        '_pair_room("t"',
        'self._relay_test_peers',
        'set_relay_test_peers',
        'set_relay_test_mode',
    ):
        if forbidden in realtime_source or forbidden in widget_source or forbidden in main_window_source:
            raise RuntimeError(f"RelayTest encore present dans le runtime public : {forbidden}")
    if package_root.joinpath("relay_test.py").is_file() or package_root.joinpath("relay_test_contract.py").is_file():
        raise RuntimeError("Module RelayTest encore distribue dans le runtime public.")

    # Raw HUD text remains local. Only WidgetWindow's semantic allow-list may
    # reach RealtimeShareClient; incoming_call is deliberately absent.
    if 'if kind == "hud_activity":\n            return' not in realtime_source:
        raise RuntimeError("Les notifications HUD brutes peuvent atteindre le relais temps reel.")
    for event_name in (
        "ship_enter", "ship_leave", "player_geid", "player_location",
        "armistice_location", "hangar_departure", "hangar_landing",
        "mission_execute", "mission_complete", "mission_failed",
        "incoming_mission", "regenerating",
    ):
        if f'"{event_name}"' not in realtime_source:
            raise RuntimeError(f"Evenement temps reel manquant : {event_name}")
    if '"incoming_call"' in realtime_source:
        raise RuntimeError("INCOMING CALL ne doit jamais faire partie du protocole reseau.")
    if 'self.widget_window.realtime_activity.connect(self.realtime_share.handle_local_activity)' not in main_window_source:
        raise RuntimeError("Le mapper semantique du widget n'est pas relie au client chiffre.")
    for fragment in (
        'self.realtime_activity.emit("player_location", clean)',
        'self.realtime_activity.emit("incoming_mission", "")',
        'self.realtime_activity.emit("armistice_location", location)',
        'self.realtime_activity.emit(event, location)',
        'self.realtime_activity.emit("mission_complete", "")',
        'self.realtime_activity.emit("mission_failed", "")',
        'self.realtime_activity.emit("mission_execute", "")',
        'self.realtime_activity.emit("regenerating", "")',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Emission semantique incomplete : {fragment}")
    if 'self.realtime_activity.emit("incoming_call"' in widget_source:
        raise RuntimeError("INCOMING CALL est encore emis vers le reseau.")
    if 'Generic notification mapping continues below.' in widget_source:
        raise RuntimeError("Le fallback de notifications HUD generiques est encore present.")
    if 'return self.party_player_overlay.set_activity(target, clean)' in widget_source or 'return self.party_group_overlay.set_activity(target, clean)' in widget_source:
        raise RuntimeError("Une notification HUD brute peut encore etre affichee dans la Party UI.")
    if 'Whitelist-only policy:' not in widget_source:
        raise RuntimeError("La politique de liste blanche des notifications n'est pas active.")
    for fragment in (
        'def set_group_member_location(self, handle: str, location: str) -> bool:',
        'if self.block_kind == "group":',
        'location = self._location_by_handle.get(key, "")',
        'elif kind == "player_location":',
        'changed = self.party_group_overlay.set_group_member_location(handle, clean_location) or changed',
        '"armistice_location":',
        '"hangar_departure":',
        '"hangar_landing":',
        '"mission_execute": "Executing mission"',
        '"mission_complete": "Missions accomplished"',
        '"mission_failed": "Failed missions"',
        '"incoming_mission": "INCOMING MISSION"',
        '"regenerating": "Regenerating"',
        'if self._handle_has_shared_ship_priority(handle):',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Affichage distant incomplet : {fragment}")

    # 2.0: own location belongs to the main HUD, never the principal-player title.
    for fragment in (
        'def _restore_local_title_after_ship_leave(self) -> None:',
        'changed = self.party_player_overlay.clear_activity(handle) or changed',
        "the principal player's RSI title unchanged on armistice changes.",
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Titre local/localisation 2.0 incomplet : {fragment}")
    if 'self.party_player_overlay.set_activity(local_handle, location)' in widget_source:
        raise RuntimeError("La localisation peut encore remplacer le titre du joueur principal.")

    # Shared-ship priority must remain enforced in the actual whitelist paths.
    # The old generic-notification `target` branch was deliberately removed in
    # 1.5.40, so validating that obsolete source fragment would reject a valid
    # runtime. Check the live local and remote branches instead.
    for fragment in (
        'def _shared_ship_channels(self) -> set[str]:',
        'def _handle_has_shared_ship_priority(self, handle: str) -> bool:',
        'def _enforce_shared_ship_priority(self) -> bool:',
        'local_shared_ship_priority = bool(local_handle and self._handle_has_shared_ship_priority(local_handle))',
        'if local_shared_ship_priority:',
        'if self._handle_has_shared_ship_priority(handle):',
        'changed = self._enforce_shared_ship_priority() or changed',
        'self._enforce_shared_ship_priority()',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Priorite du channel vaisseau partage incomplete : {fragment}")

    created_start = widget_source.index('        if kind in {"local_party_created", "local_party_joined", "local_party_transition"}:')
    created_end = widget_source.index('        if kind == "incoming_invite_accepted":', created_start)
    created_branch = widget_source[created_start:created_end]
    if 'ensure_identity_pending_member()' in created_branch:
        raise RuntimeError("La creation Party fabrique encore un WAITING FOR IDENTITY fantome.")
    for fragment in (
        'while self.party_group_overlay.remove_one_pending_invitation():',
        'self._party_pending_invite_deadlines.clear()',
        'must never promote/create a synthetic WAITING FOR IDENTITY row',
        'def _expire_stale_pending_invitations(self) -> None:',
        'self._party_pending_cleanup_timer.setInterval(500)',
        'self._party_persistent_geid_to_handle.clear()',
        'self._party_geid_to_handle.clear()',
        'self._party_handle_to_geid.clear()',
        'elif kind == "player_instance_geid" and payload.isdigit():',
        'self._party_recent_accepted_inviter = inviter',
        'changed = self._bind_party_identity(payload, inviter, remember=True) or changed',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Anti-fantome/WAITING incomplet : {fragment}")

    teardown_start = widget_source.index('        elif kind in {"party_disbanded", "local_party_left"}:')
    teardown_end = widget_source.index('        self._sync_party_overlay_visibility()', teardown_start)
    teardown_block = widget_source[teardown_start:teardown_end]
    for forbidden in (
        'self._party_persistent_geid_to_handle.clear()',
        'self._party_geid_to_handle.clear()',
        'self._party_handle_to_geid.clear()',
    ):
        if forbidden in teardown_block:
            raise RuntimeError("Un teardown Party efface encore la memoire d'identite du Game.log courant.")
    if 'session_revalidate_start remains the hard boundary that clears it.' not in teardown_block:
        raise RuntimeError("La frontiere de session pour la memoire d'identite Party n'est plus explicite.")

    recovery_start = game_log_source.index("            party_event = self.party_parser.parse_line(line)")
    recovery_end = game_log_source.index("            update = self.parser.parse_update(line)", recovery_start)
    recovery_block = game_log_source[recovery_start:recovery_end]
    if '"outgoing_invite"' in recovery_block or '"invite_declined"' in recovery_block:
        raise RuntimeError("Un WAITING historique peut encore etre rejoue au demarrage.")

    for fragment in (
        'if handle.casefold() not in active:',
        'def handle_realtime_identity(self, handle: str, geid: str) -> None:',
        'geid_local_evidence = geid in set(self.party_group_overlay.anonymous_geids())',
        'changed = self._bind_party_identity(geid, handle, remember=False)',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Barriere de preuve reseau incomplete : {fragment}")

    stage("Group depuis le bas + Raid top-anchor 2.1.8")
    geometry_start = widget_source.index("    def _group_full_row_geometry")
    geometry_end = widget_source.index("    def set_raid_local_handle", geometry_start)
    geometry_block = widget_source[geometry_start:geometry_end]
    for fragment in (
        'stable bottom-anchored y/height',
        'start_y = self.base_height - (count * row_h)',
        'first remote member starts in the lowest slot',
    ):
        if fragment not in geometry_block and fragment not in widget_source:
            raise RuntimeError(f"Ancrage Group depuis le bas incomplet : {fragment}")
    if 'start_y = 0.0' in geometry_block:
        raise RuntimeError("Le Group normal est encore ancre en haut.")

    # 150 px / 4 slots = 37.5 px. The first/only remote member starts at y=112.5
    # and the roster grows upward until four rows fill the complete block.
    row_h = 150.0 / 4.0
    expected_first_y = {1: 112.5, 2: 75.0, 3: 37.5, 4: 0.0}
    for count, expected_y in expected_first_y.items():
        first_y = 150.0 - (count * row_h)
        if first_y != expected_y or row_h != 37.5:
            raise RuntimeError("Geometrie Group bottom-anchor invalide.")

    raid_position_start = widget_source.index("    def _raid_animated_positions")
    raid_position_end = widget_source.index("    def is_raid_mode", raid_position_start)
    raid_position_block = widget_source[raid_position_start:raid_position_end]
    for fragment in (
        'column = index // _RAID_HUD_ROWS_PER_COLUMN',
        'row_index = index % _RAID_HUD_ROWS_PER_COLUMN',
        'column * column_width',
        'row_index * _RAID_HUD_ROW_HEIGHT',
    ):
        if fragment not in raid_position_block:
            raise RuntimeError(f"Geometrie Raid animee incomplete : {fragment}")
    # La première nameplate RAID reste ancrée à l'origine party_group.
    first_index = 0
    first_column = first_index // 4
    first_row_index = first_index % 4
    first_x = first_column * 112.0
    first_y = first_row_index * 30.0
    if first_x != 0.0 or first_y != 0.0:
        raise RuntimeError("Geometrie Raid : le premier slot n'est plus ancre a (0, 0).")


    stage("RAID groupes de vaisseaux 2.1.5")
    for fragment in (
        'from .vehicle_palette import manufacturer_from_channel_name, vehicle_hud_palette',
        '_RAID_GROUP_TRANSITION_SECONDS = 0.22',
        'def raid_grouped_rows(self)',
        'if ship_key in emitted_ship_keys:',
        'self._raid_ship_key_for_row(candidate) == ship_key',
        'def _raid_ship_marker_pen(',
        'palette = vehicle_hud_palette(manufacturer_id, ship)',
        'gradient.setColorAt(0.52, _rgba(middle, 255))',
        'self._raid_transition_timer.setInterval(16)',
        'return value * value * (3.0 - (2.0 * value))',
        'rows = self.raid_grouped_rows()',
        'painter.setPen(self._raid_ship_marker_pen(name, line_x, line_top, line_bottom))',
        'changed = self.party_group_overlay.set_group_member_ship(handle, "") or changed',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Groupement/couleur vaisseau Raid incomplet : {fragment}")
    # Le joueur local doit rester hors du RAID : raid_rows filtre toujours sa cle.
    raid_rows_start = widget_source.index("    def raid_rows")
    raid_rows_end = widget_source.index("    def raid_handles", raid_rows_start)
    raid_rows_block = widget_source[raid_rows_start:raid_rows_end]
    if 'local_key = self._render_raid_local_handle().casefold()' not in raid_rows_block:
        raise RuntimeError("Le joueur local n'est plus explicitement exclu du RAID.")
    if '(local_key and key == local_key)' not in raid_rows_block:
        raise RuntimeError("Le filtre du joueur local dans raid_rows a regresse.")

    stage("RAID comportement vaisseau + leader sans couleur 2.1.18 / validateur robuste 2.1.19")
    # Regression 2.1.14: the grouping/rendering code existed, but model-only
    # channel names such as Perseus/Ironclad were rejected before ship_join.
    for ship_name, expected_manufacturer in (
        ("Perseus", "rsi"),
        ("Ironclad", "drake"),
        ("Ironclad Assault", "drake"),
        ("Shiv", "greys-market"),
    ):
        manufacturer = manufacturer_from_channel_name(ship_name)
        if manufacturer != expected_manufacturer:
            raise RuntimeError(
                f"Canal vaisseau autonome non reconnu : {ship_name} -> {manufacturer!r}"
            )

    parser_fixture = PartyContextParser()
    for handle, ship_name in (
        ("Alpha", "Perseus"),
        ("Bravo", "Perseus"),
        ("Charlie", "Ironclad"),
        ("Delta", "Perseus"),
    ):
        event = parser_fixture.parse_line(
            f"<2099-01-01T01:00:00.000Z> {handle} has joined the channel '{ship_name} : {handle}'"
        )
        if event is None or event.kind != "ship_join" or event.handle != handle or event.ship_name != ship_name:
            raise RuntimeError(f"ship_join RAID perdu pour {handle}/{ship_name}: {event!r}")

    qt_app = QApplication.instance() or QApplication([])
    raid_fixture = PartyHudBlock("group")
    for handle in ("Alpha", "Charlie", "Bravo", "Delta"):
        raid_fixture.upsert_group_member(handle)
    raid_fixture.set_group_member_ship("Alpha", "Perseus")
    raid_fixture.set_group_member_ship("Bravo", "Perseus")
    raid_fixture.set_group_member_ship("Delta", "Perseus")
    raid_fixture.set_group_member_ship("Charlie", "Ironclad")
    grouped_handles = tuple(str(row[0]) for row in raid_fixture.raid_grouped_rows())
    # Contract: occupants of the same ship must be contiguous. The Party HUD
    # historically inserts members from the anchor direction, so their internal
    # order may legitimately be Alpha/Bravo/Delta or Delta/Bravo/Alpha. Do not
    # turn that visual anchoring detail into a false installation failure.
    perseus_members = {"Alpha", "Bravo", "Delta"}
    perseus_positions = sorted(
        index for index, handle in enumerate(grouped_handles) if handle in perseus_members
    )
    if set(grouped_handles) != {"Alpha", "Bravo", "Charlie", "Delta"}:
        raise RuntimeError(f"Membres RAID perdus ou dupliques : {grouped_handles!r}")
    if len(perseus_positions) != 3 or perseus_positions != list(
        range(perseus_positions[0], perseus_positions[0] + len(perseus_positions))
    ):
        raise RuntimeError(f"Occupants du Perseus non adjacents : {grouped_handles!r}")
    if grouped_handles[perseus_positions[-1] + 1 :] != ("Charlie",):
        raise RuntimeError(f"Ordre des groupes vaisseau RAID incoherent : {grouped_handles!r}")
    raid_fixture.set_party_leader_handle("Bravo")
    if not raid_fixture.is_party_leader("Bravo") or raid_fixture.is_party_leader("Alpha"):
        raise RuntimeError("Suivi du leader Party incorrect.")
    leader_pen = raid_fixture._raid_ship_marker_pen("Bravo", 5.0, 5.0, 25.0)
    ship_pen = raid_fixture._raid_ship_marker_pen("Alpha", 5.0, 5.0, 25.0)

    def _pen_signature(pen):
        gradient = pen.brush().gradient()
        stops = tuple(
            (round(float(position), 4), int(color.rgba()))
            for position, color in (gradient.stops() if gradient is not None else ())
        )
        return round(float(pen.widthF()), 4), stops

    if _pen_signature(leader_pen) != _pen_signature(ship_pen):
        raise RuntimeError("Le leader RAID conserve encore une couleur differente des occupants du meme vaisseau.")

    # Leadership must remain fully tracked even though it has no special colour.
    for fragment in (
        'changed = self._set_party_leader(local_handle, local_is_leader=True) or changed',
        'changed = self._set_party_leader(inviter, local_is_leader=False) or changed',
        'if kind == "party_leader":',
        'def is_party_leader(self, handle: str) -> bool:',
    ):
        if fragment not in widget_source:
            raise RuntimeError(f"Propagation leader incomplete : {fragment}")
    for forbidden in (
        '_PARTY_LEADER_GOLD',
        'if self.is_party_leader(handle):',
        '_PARTY_LEADER_GOLD if self.is_party_leader(name) else None',
    ):
        if forbidden in widget_source:
            raise RuntimeError(f"Couleur speciale leader encore presente : {forbidden}")

    # The normal Party/player separator lines must no longer pass a leader colour.
    # Extract each method up to the next class method rather than naming the next
    # method explicitly. 2.1.18 failed installation because the validator still
    # expected the obsolete `_paint_group_reduced` name even though the runtime
    # correctly uses `_paint_group_compact` / `_paint_group_minimal`.
    player_paint_block = method_block(widget_source, "_paint_player")
    if 'self._draw_line(painter, 54.0, 10.0, 205.0)' not in player_paint_block:
        raise RuntimeError("Trait joueur principal n'utilise plus la couleur normale attendue.")
    group_paint_block = method_block(widget_source, "_paint_group_full")
    if 'self._draw_line(painter, 25.0, avatar_y + 1.0, 101.0)' not in group_paint_block:
        raise RuntimeError("Trait Group n'utilise plus la couleur normale attendue.")
    if "    def _paint_group_compact" not in widget_source:
        raise RuntimeError("Mode Group compact attendu absent du runtime courant.")

    stage("HUD Editor Group footprint 2.1.8")
    visual_start = widget_source.index("    def visual_base_height")
    visual_end = widget_source.index("    def has_live_content", visual_start)
    visual_block = widget_source[visual_start:visual_end]
    for fragment in (
        'self._editor_preview_rows is not None',
        'Bottom anchoring uses the full four-slot 150 px reference block',
        'return int(self.base_height)',
    ):
        if fragment not in visual_block:
            raise RuntimeError(f"Empreinte HUD Editor Group incomplete : {fragment}")
    if 'int(math.ceil(visible_rows * row_h))' in visual_block:
        raise RuntimeError("Le preview Group est encore tronque a 113 px.")
    expected_preview_height = 150
    if expected_preview_height != 150:
        raise RuntimeError("Hauteur preview Group HUD Editor invalide.")
    if 'party_group_preview_height=(\n                    self.widget_window.party_group_overlay.visual_base_height()' not in main_window_source:
        raise RuntimeError("Le HUD Editor ne lit plus la hauteur visuelle du bloc Group.")


    stage("Application immediate Game.log + feedback Save + Raid 2.1.2")
    for fragment in (
        'self.save_button.setText(self._t("APPLIQUÉ", "APPLIED"))',
        'background: #d9b83f',
        'self._show_save_feedback()',
    ):
        if fragment not in settings_source:
            raise RuntimeError(f"Feedback Save settings incomplet : {fragment}")
    for fragment in (
        'def _configured_existing_path(self) -> Path | None:',
        'def _selected_existing_path(self) -> Path | None:',
        'selected = self._selected_existing_path()',
        'A manual selection is an explicit user choice',
    ):
        if fragment not in game_log_source:
            raise RuntimeError(f"Application immediate Game.log incomplete : {fragment}")
    raid_paint_start = widget_source.index("    def _paint_group_raid")
    raid_paint_end = widget_source.index("    def paintEvent", raid_paint_start)
    raid_paint_block = widget_source[raid_paint_start:raid_paint_end]
    for fragment in (
        'painter.setPen(self._raid_ship_marker_pen(name, line_x, line_top, line_bottom))',
        'painter.drawLine(QPointF(line_x, line_top), QPointF(line_x, line_bottom))',
        'if not image.isNull():',
        'text_x = content_x + title_icon_size + icon_gap',
        'painter.drawText(',
        'placeholder_x = x + column_width - placeholder_size - 5.0',
    ):
        if fragment not in raid_paint_block:
            raise RuntimeError(f"Ordre icone/titre Raid incomplet : {fragment}")
    marker_index = raid_paint_block.index(
        'painter.drawLine(QPointF(line_x, line_top), QPointF(line_x, line_bottom))'
    )
    title_icon_index = raid_paint_block.index('if not image.isNull():')
    handle_index = raid_paint_block.index('painter.drawText(')
    if not marker_index < title_icon_index < handle_index:
        raise RuntimeError(
            "Ordre Raid invalide : le rendu doit rester trait -> icone de titre -> handle."
        )

    with tempfile.TemporaryDirectory(prefix="sc-rtlt-gamelog-switch-") as temp_dir:
        temp = Path(temp_dir)
        configured_log = temp / "selected" / "Game.log"
        active_log = temp / "old-active" / "Game.log"
        configured_log.parent.mkdir()
        active_log.parent.mkdir()
        configured_log.write_text("selected\n", encoding="utf-8")
        active_log.write_text("active\n", encoding="utf-8")
        now = configured_log.stat().st_mtime
        os.utime(configured_log, (now - 30, now - 30))
        os.utime(active_log, (now + 30, now + 30))
        switch_settings = QSettings(str(temp / "settings.ini"), QSettings.Format.IniFormat)
        switch_settings.setValue("game_log/path", str(configured_log))
        switch_settings.setValue("game_log/active_path", str(active_log))
        switch_settings.setValue("game_log/auto_location_enabled", True)
        monitor = GameLogLocationMonitor(switch_settings)
        try:
            if monitor._selected_existing_path() != configured_log:
                raise RuntimeError("Le Game.log manuel ne gagne pas contre un ancien fichier plus recent.")
        finally:
            monitor.shutdown()

    stage("Ressources + profil RSI synthetique")
    for resource_name in (
        "assets/app_icon.png",
        "assets/app_icon.ico",
        "assets/party_profile_loading.png",
        "assets/avatar_displacement_map.png",
        "assets/vehicle_hud_palettes.json",
        "assets/location_mappings.json",
        "widget_window.py",
        "settings_page.py",
        "party_context.py",
        "realtime_share.py",
        "rsi_profile.py",
    ):
        if not package_root.joinpath(resource_name).is_file():
            raise FileNotFoundError(f"Ressource absente : {resource_name}")

    synthetic_profile_html = (
        '<html><body><h2>Main organization</h2>'
        '&lt;div class=&quot;box-cc&quot;&gt;&lt;span&gt;Synthetic Org&lt;/span&gt;&lt;/div&gt; '
        'Spectrum Identification (SID): SYNTH</body></html>'
    )
    parsed_org, _parsed_url, parsed_resolved = parse_citizen_organizations_html(
        synthetic_profile_html,
        "https://robertsspaceindustries.com/en/citizens/Player_A/organizations",
    )
    if not parsed_resolved or parsed_org != "Synthetic Org":
        raise RuntimeError(f"Decodage HTML RSI incorrect : {parsed_org!r}")

    stage("Validation terminee")
    print(
        "Validation runtime OK — "
        f"SC-RTLT Public {sc_web_companion.__version__}, PySide6 {PySide6.__version__}",
        flush=True,
    )
except BaseException as exc:
    fail(exc)
    raise SystemExit(1)
