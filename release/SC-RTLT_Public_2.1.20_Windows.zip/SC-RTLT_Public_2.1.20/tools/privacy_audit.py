from __future__ import annotations

import json
import re
import sys
import zipfile
from pathlib import Path

TEXT_SUFFIXES = {".py", ".txt", ".md", ".json", ".ps1", ".cmd", ".bat", ".vbs", ".csv"}
PATTERNS = {
    "email": re.compile(r"\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b", re.I),
    "personal_windows_path": re.compile(r"[A-Za-z]:\\Users\\(?!(?:<nom>|<name>)\\)[^\\\s\"']+", re.I),
    "github_token": re.compile(r"(?:github_pat_[A-Za-z0-9_]+|ghp_[A-Za-z0-9]+)", re.I),
    "api_secret": re.compile(r"(?:sk-[A-Za-z0-9_-]{16,}|Bearer\s+[A-Za-z0-9._-]{16,})", re.I),
    "real_dated_log_fixture": re.compile(r"<20(?:[0-8][0-9])-[0-9]{2}-[0-9]{2}T"),
}


def scan_text(label: str, text: str) -> list[str]:
    failures: list[str] = []
    for name, pattern in PATTERNS.items():
        if pattern.search(text):
            failures.append(f"{label}: {name}")
    return failures


def main() -> int:
    root = Path(sys.argv[1] if len(sys.argv) > 1 else ".").resolve()
    failures: list[str] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        if path.suffix.lower() in TEXT_SUFFIXES:
            try:
                failures.extend(scan_text(str(path.relative_to(root)), path.read_text(encoding="utf-8-sig")))
            except UnicodeDecodeError:
                pass
        if path.suffix.lower() == ".whl":
            with zipfile.ZipFile(path) as archive:
                for info in archive.infolist():
                    suffix = Path(info.filename).suffix.lower()
                    if suffix not in TEXT_SUFFIXES:
                        continue
                    try:
                        text = archive.read(info).decode("utf-8-sig")
                    except UnicodeDecodeError:
                        continue
                    failures.extend(scan_text(f"{path.name}:{info.filename}", text))
                    if info.filename.endswith("assets/location_mappings.json"):
                        payload = json.loads(text)
                        if payload.get("mappings") != []:
                            failures.append(f"{path.name}:{info.filename}: bundled user-derived mappings")
                    if info.filename.endswith("assets/location_stream_signatures.json"):
                        failures.append(f"{path.name}:{info.filename}: captured signature dataset must not ship")
    if failures:
        print("[PRIVACY][FAIL]")
        for failure in failures:
            print(f"- {failure}")
        return 1
    print("[PRIVACY][OK] No forbidden distribution data detected by generic scan.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
